const Page = (): JSX.Element => {
  return (
    <div className="h-dvh w-screen flex justify-center items-center">
      
    </div>
  );
};

export default Page;
