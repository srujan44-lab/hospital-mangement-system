import { AppointmentTable } from "@/components/tables/admin/appointment-table";

const Page = (): JSX.Element => {
  return (
    <AppointmentTable />
  );
};

export default Page;
