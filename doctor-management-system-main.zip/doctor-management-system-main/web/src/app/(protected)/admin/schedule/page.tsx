import { ScheduleTable } from "@/components/tables/admin/schedule-table";

const Page = (): JSX.Element => {
  return (
    <ScheduleTable />
  );
};

export default Page;
