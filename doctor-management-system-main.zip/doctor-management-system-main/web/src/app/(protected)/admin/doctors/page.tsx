import { DoctorTable } from "@/components/tables/admin/doctor-table";

const Page = (): JSX.Element => {
  return (
    <DoctorTable />
  );
};

export default Page;
