import { PatientTable } from "@/components/tables/admin/patient-table";

const Page = (): JSX.Element => {
  return (
    <PatientTable />
  );
};

export default Page;
