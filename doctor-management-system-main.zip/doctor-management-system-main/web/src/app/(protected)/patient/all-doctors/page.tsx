import { DoctorTable } from "@/components/tables/patient/doctor-table";

const Page = (): JSX.Element => {
  return (
    <DoctorTable />
  );
};

export default Page;
