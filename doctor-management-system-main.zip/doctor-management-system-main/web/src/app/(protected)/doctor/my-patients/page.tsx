import { MyPatientTable } from "@/components/tables/doctor/my-patient-table";

const Page = (): JSX.Element => {
  return (
    <MyPatientTable />
  );
};

export default Page;
