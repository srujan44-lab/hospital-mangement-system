import { MySessionTable } from "@/components/tables/doctor/my-session-table";

const Page = (): JSX.Element => {
  return (
    <MySessionTable />
  );
};

export default Page;
