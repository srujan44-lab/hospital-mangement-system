import { MyAppointmentTable } from "@/components/tables/doctor/my-appointment-table";

const Page = (): JSX.Element => {
  return (
    <MyAppointmentTable />
  );
};

export default Page;
