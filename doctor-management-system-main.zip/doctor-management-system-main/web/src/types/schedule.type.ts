export interface ScheduleType {
  scheduleid: number;
  docid: string;
  title: string;
  scheduledate: string;
  scheduletime: string;
  nop: number;
  appointment_count: number;
}