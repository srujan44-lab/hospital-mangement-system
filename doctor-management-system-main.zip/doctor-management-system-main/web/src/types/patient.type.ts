export interface PatientType {
  name: string;
  email: string;
  mobileNumber: string;
}