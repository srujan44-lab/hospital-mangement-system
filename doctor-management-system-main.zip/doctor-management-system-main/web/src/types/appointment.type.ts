export interface AppointmentType {
  appoid: number;
  scheduleid: number;
  pid: string;
  apponum: number;
  appodate: string;
}