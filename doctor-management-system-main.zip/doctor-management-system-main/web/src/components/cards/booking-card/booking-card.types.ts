export interface BookingCardProps {
  title: string;
  appointmentNumber: number;
  name: string;
  date: string;
  time: string;
  id: number;
}