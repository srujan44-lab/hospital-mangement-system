export interface ScheduleCardProps {
  title: string;
  name: string;
  date: string;
  time: string;
  email: string;
  id: number;
  appointmentCount: number;
}