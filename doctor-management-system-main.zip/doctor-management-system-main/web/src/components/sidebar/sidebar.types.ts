export interface sidebarListType {
  url: string;
  value: string;
}