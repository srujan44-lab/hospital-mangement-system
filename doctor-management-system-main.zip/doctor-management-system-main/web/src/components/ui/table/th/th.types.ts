import { ThHTMLAttributes } from "react";

export interface ThProps extends ThHTMLAttributes<HTMLTableHeaderCellElement> {}
