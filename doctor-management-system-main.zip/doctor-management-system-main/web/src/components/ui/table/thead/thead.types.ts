import { TableHTMLAttributes } from "react";

export interface TheadProps extends TableHTMLAttributes<HTMLTableSectionElement> {}
