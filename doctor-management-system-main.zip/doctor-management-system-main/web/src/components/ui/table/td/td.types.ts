import { TdHTMLAttributes } from "react";

export interface TdProps extends TdHTMLAttributes<HTMLTableDataCellElement> {}
