import { TableHTMLAttributes } from "react";

export interface TrProps extends TableHTMLAttributes<HTMLTableRowElement> {}
