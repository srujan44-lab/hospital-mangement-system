import { TableHTMLAttributes } from "react";

export interface TbodyProps extends TableHTMLAttributes<HTMLTableSectionElement> {}
